package com.fooddelivery.delivery.entity;

public enum RoleName {
    ADMIN,        
    RESTAURANT,   
    CUSTOMER      
}
